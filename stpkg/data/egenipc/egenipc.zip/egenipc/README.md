# egenipc

<!-- badges: start -->

[![Lifecycle:
experimental](https://img.shields.io/badge/lifecycle-experimental-orange.svg)](https://www.tidyverse.org/lifecycle/#experimental)
<!-- badges: end -->

处理专利分类号的一些自编 egen 函数～ 自用命令包，仅供参考。

欢迎大家关注微信公众号“RStata” 和 “Stata 中文社区” 获取最新资讯和动态！

|                                             RStata                                              |                                          Stata中文社区                                          |
|:-----------------------------------------------------------------------------------------------:|:-----------------------------------------------------------------------------------------------:|
| <img src="https://mdniceczx.oss-cn-beijing.aliyuncs.com/image_20201120143454.png" width="50%"/> | <img src="https://mdniceczx.oss-cn-beijing.aliyuncs.com/image_20201120143508.png" width="50%"/> |

## 安装方法

你可以从 GitHub 上安装这个 R 包：

```stata
net install egenipc.pkg, from("egenipc.pkg 文件所在的文件夹路径")
```

## 使用介绍

1. `_gipc_pk.ado`：用于根据 IPC 分类号计算专利知识宽度，方法参考 「创新追赶战略抑制了中国专利质量么_张杰」，基于大组衡量。用法示例：`egen patentknowledge = ipc_pk(IPC), parse(;)`
1. `_gipc_count.ado`：用于统计字符串变量使用特定分隔符切分得到的子字符串数量。使用示例：`egen n2 = ipc_count(IPC), parse(;)` 
1. `_gipc_sub_count.ado`：用于统计字符串使用特定字符拆分后，子字符串的子字符串互不相同的数量，例如前 3 位的。使用示例：`egen n4 = ipc_sub_count(IPC), parse(;) from(1) to(3)` 
1. `_gipc_sub.ado`：用于提取字符串使用特定字符拆分后得到的子字符串特定范围的子字符串。使用示例：`egen subipc = ipc_sub(IPC), parse(;) from(1) to(3)`
1. `_gipc_sub0.ado`：用于统计字符串使用特定字符拆分后，第 n 个子字符串。使用示例：`egen IPC_main = ipc_sub0(IPC), parse(;) choose(1)`
1. `_gipc_sub2_unique.ado`：用于将字符串使用特定字符拆分后，再对子字符串使用另一字符拆分，进而提取拆分结果的第 n 部分（去除重复的）。使用示例：`egen sub2ipc3 = ipc_sub2_unique(IPC), parse(;) parse2(/) choose(1)`
1. `_gipc_sub2.ado`：用于将字符串使用特定字符拆分后，再对子字符串使用另一字符拆分，进而提取拆分结果的第 n 部分。使用示例：`egen sub2ipc = ipc_sub2(IPC), parse(;) parse2(/) choose(1)`
1. `_gipc_sumstr.ado`：用于分组加总连接字符串
1. `_gipc_unique_count.ado`：统计互不相同的数量
1. `_gipc_unique_sub.ado`：用于提取字符串使用特定字符拆分后得到的子字符串特定范围的子字符串（去除重复的）。使用示例：`egen subipc_unique14 = ipc_unique_sub(IPC), parse(;) from(1) to(4)` 
1. `_gipc_unique.ado`：用于将字符串使用特定字符拆分后，提取所有互不相同的结果。使用示例：`egen sub2ipc_unique = ipc_unique(sub2ipc), parse(;)` 
1. `_gipc_sub00.ado`：用于统计字符串使用特定字符拆分后，第 1-n 个子字符串。使用示例：`egen IPC_main = ipc_sub00(IPC), parse(;) choose(3)` 

------------------------------------------------------------------------

<h4 align="center">
License
</h4>
<h6 align="center">
MIT © 微信公众号 RStata
</h6>
