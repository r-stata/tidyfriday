*! 微信公众号 RStata
*! 用于分组加总连接字符串
*! 使用示例：
program define _gipc_sumstr
    version 6.0

    gettoken type 0 : 0
    gettoken g    0 : 0
    gettoken eqs  0 : 0

    syntax varlist(max=1 string), parse(string) by(string) 

    if "`parse'" == "" { 
        local parse = ";"
    } 

    qui mata: strsum("`varlist'", "`parse'", "`by'")
    rename newufvar `g' 
end

mata: 
void strsum(string x, string parse, string by) {
    ipc = st_sdata(., x)
    by2 = st_data(., by) 
    a = uniqrows(by2) 
    b = J(rows(a), 1, "") 
    for(z=1;z<=rows(a);z++){
        for(t=1;t<=rows(ipc);t++) {
            if (a[z] == by2[t]) {
                b[z] = b[z] + parse + ipc[t]
            }
        }
    }
    ipccountres = J(rows(ipc), 1, "") 
    for(t=1;t<=rows(ipc);t++) {
        for(z=1;z<=rows(a);z++) {
            if (a[z] == by2[t]) {
                ipccountres[t] = b[z]
            } 
        }
    } 
    stata("cap drop newufvar")
    st_addvar("strL", "newufvar")
    st_sstore(., "newufvar", ipccountres)
}
end 
