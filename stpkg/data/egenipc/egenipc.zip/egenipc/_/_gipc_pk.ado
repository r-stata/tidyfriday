*! 微信公众号 RStata
*! 用于根据 IPC 分类号计算专利知识宽度，方法参考 「创新追赶战略抑制了中国专利质量么_张杰」，基于大组衡量。
*! 用法示例：egen patentknowledge = ipc_pk(IPC), parse(;) 
program define _gipc_pk
    version 6.0

    gettoken type 0 : 0
    gettoken g    0 : 0
    gettoken eqs  0 : 0

    syntax varlist(max=1 string), parse(string) 

    if "`parse'" == "" { 
        local parse = ";"
    } 

    qui mata: ipc_pk("`varlist'", "`parse'")
    rename newufvar `g' 
end

mata: 
string vector uniquerow(string vector x) {
    b = uniqrows(rowshape(x, cols(x))) 
    return(colshape(b, rows(b))) 
} 
void ipc_pk(string x, string parse) {
    v = st_sdata(., x)
    ipccountres = J(rows(v), 1, .)
    for(z=1;z<=rows(v);z++){
        a = ustrsplit(v[z], parse)
        aa = J(1, cols(a), "")
        for(t=1;t<=cols(a);t++){
            b = ustrsplit(a[t], "/") 
            aa[t] = b[1] 
        }
        bb = uniquerow(aa) 
        cc = J(1, cols(bb), 0)
        for(i=1;i<=cols(bb);i++) {
            for(j=1;j<=cols(aa);j++) {
                if(aa[j]==bb[i]) {
                    cc[i] = cc[i] + 1
                }
            }
        }
        ipccountres[z] = 1 - sum((cc/sum(cc)):^2)
    }
    stata("cap drop newufvar")
    st_addvar("double", "newufvar")
    st_store(., "newufvar", ipccountres)
}
end 
