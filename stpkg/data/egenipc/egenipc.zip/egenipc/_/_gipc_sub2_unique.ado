*! 微信公众号 RStata
*! 用于将字符串使用特定字符拆分后，再对子字符串使用另一字符拆分，进而提取拆分结果的第 n 部分（去除重复的）
*! 使用示例：egen sub2ipc3 = ipc_sub2_unique(IPC), parse(;) parse2(/) choose(1)
program define _gipc_sub2_unique
    version 6.0

    gettoken type 0 : 0
    gettoken g    0 : 0
    gettoken eqs  0 : 0

    syntax varlist(max=1 string), parse(string) parse2(string) choose(integer)

    if "`parse'" == "" { 
        local parse = ";"
    } 

    if "`parse2'" == "" { 
        local parse2 = "/"
    } 

    qui mata: ipc_sub2_unique("`varlist'", "`parse'", "`parse2'", `choose')
    rename newufvar `g' 
end

mata: 
string vector uniquerow(string vector x) {
    b = uniqrows(rowshape(x, cols(x))) 
    return(colshape(b, rows(b)))
}
void ipc_sub2_unique(string x, string parse, string parse2, numeric choose) {
    v = st_sdata(., x)
    ipccountres = J(rows(v), 1, "")
    for(z=1;z<=rows(v);z++){
        a = ustrsplit(v[z], parse)
        ipccountres2 = J(1, cols(a), "")
        for(t=1;t<=cols(a);t++){
            b = ustrsplit(a[t], parse2)
            if (choose <= cols(b)) {
                ipccountres2[t] = b[choose] 
            }
        }
        ipccountres[z] = invtokens(uniquerow(ipccountres2), parse)
    }
    stata("cap drop newufvar")
    st_addvar("strL", "newufvar")
    st_sstore(., "newufvar", ipccountres)
}
end 
