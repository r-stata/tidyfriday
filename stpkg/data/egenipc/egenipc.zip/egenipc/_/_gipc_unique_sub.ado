*! 微信公众号 RStata
*! 用于提取字符串使用特定字符拆分后得到的子字符串特定范围的子字符串（去除重复的）
*! 使用示例：egen subipc_unique14 = ipc_unique_sub(IPC), parse(;) from(1) to(4) 
program define _gipc_unique_sub
    version 6.0

    gettoken type 0 : 0
    gettoken g    0 : 0
    gettoken eqs  0 : 0

    syntax varlist(max=1 string), parse(string) from(integer) to(integer)

    if "`parse'" == "" { 
        local parse = ";"
    } 

    qui mata: ipc_unique_sub("`varlist'", "`parse'", `from', `to')
    rename newufvar `g' 
end

mata: 
string vector uniquerow(string vector x) {
    b = uniqrows(rowshape(x, cols(x))) 
    return(colshape(b, rows(b)))
}
void ipc_unique_sub(string x, string parse, numeric from, numeric to) {
    v = st_sdata(., x)
    ipccountres = J(rows(v), 1, "")
    for(z=1;z<=rows(v);z++){
        a = ustrsplit(v[z], parse)
        b = substr(a, from, to)
        ipccountres[z] = invtokens(uniquerow(b), parse)
    }
    stata("cap drop newufvar")
    st_addvar("strL", "newufvar")
    st_sstore(., "newufvar", ipccountres)
}
end 
