*! 微信公众号 RStata
*! 用于统计字符串使用特定字符拆分后，子字符串的子字符串互不相同的数量，例如前 3 位的
*! 使用示例：egen n4 = ipc_sub_count(IPC), parse(;) from(1) to(3) 
program define _gipc_sub_count 
    version 6.0

    gettoken type 0 : 0
    gettoken g    0 : 0
    gettoken eqs  0 : 0

    syntax varlist(max=1 string), parse(string) from(integer) to(integer)

    if "`parse'" == "" { 
        local parse = ";"
    } 

    qui mata: ipc_sub_count("`varlist'", "`parse'", `from', `to')
    rename newufvar `g' 
end

mata: 
string vector uniquerow(string vector x) {
    b = uniqrows(rowshape(x, cols(x))) 
    return(colshape(b, rows(b)))
}
void ipc_sub_count(string x, string parse, numeric from, numeric to) {
    v = st_sdata(., x)
    ipccountres = J(rows(v), 1, .)
    for(z=1;z<=rows(v);z++){
        a = ustrsplit(v[z], parse)
        b = substr(a, from, to)
        ipccountres[z] = cols(uniquerow(b))
    }
    stata("cap drop newufvar")
    st_addvar("double", "newufvar")
    st_store(., "newufvar", ipccountres)
}
end 
