*! 微信公众号 RStata
*! 用于将字符串使用特定字符拆分后，提取所有互不相同的结果
*! 使用示例：egen sub2ipc_unique = ipc_unique(sub2ipc), parse(;) 
program define _gipc_unique 
    version 6.0

    gettoken type 0 : 0
    gettoken g    0 : 0
    gettoken eqs  0 : 0

    syntax varlist(max=1 string), parse(string)

    if "`parse'" == "" {
        local parse = ";"
    }

    qui mata: ipc_unique("`varlist'", "`parse'")
    rename newufvar `g' 
end

mata: 
void ipc_unique(string x, string parse) {
    v = st_sdata(., x)
    uniquefunres = J(rows(v), 1, "")
    for(z=1;z<=rows(v);z++){
        a = ustrsplit(v[z], parse)
        b = uniqrows(rowshape(a, cols(a)))
        uniquefunres[z] = invtokens(colshape(b, rows(b)), parse)
    }
    st_addvar("strL", "newufvar")
    st_sstore(., "newufvar", uniquefunres)
}
end 
