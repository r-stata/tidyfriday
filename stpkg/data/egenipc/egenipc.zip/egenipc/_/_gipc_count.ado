*! 微信公众号 RStata
*! 用于统计字符串变量使用特定分隔符切分得到的子字符串数量
*! 使用示例：egen n2 = ipc_count(IPC), parse(;) 
program define _gipc_count
    version 6.0

    gettoken type 0 : 0
    gettoken g    0 : 0
    gettoken eqs  0 : 0

    syntax varlist(max=1 string), parse(string)

    if "`parse'" == "" {
        local parse = ";"
    }

    qui mata: ipc_count("`varlist'", "`parse'")
    rename newufvar `g' 
end

mata: 
void ipc_count(string x, string parse) {
    v = st_sdata(., x)
    ipccountres = J(rows(v), 1, .)
    for(z=1;z<=rows(v);z++){
        a = ustrsplit(v[z], parse)
        ipccountres[z] = cols(a)
    }
    stata("cap drop newufvar")
    st_addvar("double", "newufvar")
    st_store(., "newufvar", ipccountres)
}
end 
