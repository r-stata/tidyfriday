*- 微信公众号 RStata
program define _gipc_unique_count 
    version 6.0

    gettoken type 0 : 0
    gettoken g    0 : 0
    gettoken eqs  0 : 0

    syntax varlist(max=1 string), parse(string)

    if "`parse'" == "" {
        local parse = ";"
    }

    qui mata: ipc_unique_count("`varlist'", "`parse'")
    rename newufvar `g' 
end

mata: 
string vector uniquerow(string vector x) {
    b = uniqrows(rowshape(x, cols(x))) 
    return(colshape(b, rows(b)))
}
void ipc_unique_count(string x, string parse) {
    v = st_sdata(., x)
    ipccountres = J(rows(v), 1, .)
    for(z=1;z<=rows(v);z++){
        a = ustrsplit(v[z], parse)
        ipccountres[z] = cols(uniquerow(a))
    }
    stata("cap drop newufvar")
    st_addvar("double", "newufvar")
    st_store(., "newufvar", ipccountres)
}
end 
