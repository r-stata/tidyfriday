*! 微信公众号 RStata
*! 用于统计字符串使用特定字符拆分后，第 1-n 个子字符串
*! 使用示例：egen IPC_main = ipc_sub00(IPC), parse(;) choose(3)
program define _gipc_sub00
    version 6.0

    gettoken type 0 : 0
    gettoken g    0 : 0
    gettoken eqs  0 : 0

    syntax varlist(max=1 string), parse(string) choose(integer) 

    if "`parse'" == "" { 
        local parse = ";"
    } 

    qui mata: ipc_sub00("`varlist'", "`parse'", `choose')
    rename newufvar `g' 
end

mata: 
void ipc_sub00(string x, string parse, numeric choose) {
    v = st_sdata(., x)
    ipccountres = J(rows(v), 1, "") 
    for(z=1;z<=rows(v);z++){
        a = ustrsplit(v[z], parse)
        if (choose <= rows(a)) {
            ipccountres[z] = a[1..choose] 
        }
    }
    stata("cap drop newufvar")
    st_addvar("strL", "newufvar")
    st_sstore(., "newufvar", ipccountres)
}
end 
