## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----message=FALSE, warning=FALSE, error=FALSE--------------------------------
library(worldtilegrid)
library(ggplot2)

## ----echo=TRUE, eval=FALSE----------------------------------------------------
#  str(wtg)

## ----echo=FALSE---------------------------------------------------------------
str(wtg, give.attr = FALSE)

## ----message=FALSE, warning=FALSE, error=FALSE, fig.width=6, fig.height=6-----
set.seed(1)
data.frame(
  ctry = worldtilegrid::wtg$alpha.3,
  val = sample(1000, length(worldtilegrid::wtg$alpha.3)),
  stringsAsFactors = FALSE
) -> xdf

ggplot(xdf, aes(country = ctry, fill = val)) +
  geom_wtg() +
  geom_text(aes(label = stat(alpha.2)), stat="wtg", size=2) + # re-compute the stat to label
  coord_equal() +
  viridis::scale_fill_viridis(direction = -1) +
  labs(title = "World Tile Grid") +
  theme_minimal() +
  theme_enhance_wtg()

## ----message=FALSE, warning=FALSE, error=FALSE, fig.width=6, fig.height=6-----
set.seed(1)
data.frame(
  ctry = worldtilegrid::wtg$alpha.3[1:30],
  val = sample(1000, length(worldtilegrid::wtg$alpha.3[1:30])),
  stringsAsFactors = FALSE
) -> xdf

ggplot(xdf, aes(country = ctry, fill = val)) +
  geom_wtg() +
  geom_text(aes(label = stat(alpha.2)), stat="wtg", size=2) + # re-compute the stat to label
  coord_equal() +
  viridis::scale_fill_viridis(direction = -1) +
  labs(title = "World Tile Grid") +
  theme_minimal() +
  theme_enhance_wtg()

## ----message=FALSE, warning=FALSE, error=FALSE, fig.width=10, fig.height=6----
set.seed(1)
data.frame(
  ctry = worldtilegrid::wtg$alpha.3,
  val = sample(1000, length(worldtilegrid::wtg$alpha.3)),
  grp = 'Thing One',
  stringsAsFactors = FALSE
) -> xdf1

data.frame(
  ctry = worldtilegrid::wtg$alpha.3,
  val = sample(1000, length(worldtilegrid::wtg$alpha.3)),
  grp = 'Thing Two',
  stringsAsFactors = FALSE
) -> xdf2

rbind.data.frame(
  xdf1,
  xdf2
) -> xdf

ggplot(xdf, aes(country = ctry, fill = val)) +
  geom_wtg() +
  coord_equal() +
  facet_wrap(~grp) +
  viridis::scale_fill_viridis(direction = -1) +
  labs(title = "World Tile Grid Facets") +
  theme_minimal() +
  theme_enhance_wtg()

## ----message=FALSE, warning=FALSE, error=FALSE, fig.width=10, fig.height=6----
set.seed(1)
data.frame(
  ctry = c("USA", "MEX", "CAN", "RUS", "BRA"),
  val = sample(1000, length(c("USA", "MEX", "CAN", "RUS", "BRA"))),
  grp = 'Thing One',
  stringsAsFactors = FALSE
) -> xdf1

data.frame(
  ctry = c("USA", "MEX", "CAN", "RUS", "BRA"),
  val = sample(1000, length(c("USA", "MEX", "CAN", "RUS", "BRA"))),
  grp = 'Thing Two',
  stringsAsFactors = FALSE
) -> xdf2

rbind.data.frame(
  xdf1,
  xdf2
) -> xdf

ggplot(xdf, aes(country = ctry, fill = val)) +
  geom_wtg() +
  coord_equal() +
  facet_wrap(~grp) +
  viridis::scale_fill_viridis(direction = -1) +
  labs(title = "World Tile Grid Facets") +
  theme_minimal() +
  theme_enhance_wtg()

